﻿Imports System.Data.SqlClient
Public Class WebForm3
    Inherits System.Web.UI.Page

    Dim cs As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Linux\Documents\Visual Studio 2010\Projects\PriyaProject\PriyaProject\App_Data\db_bismilla.mdf;Integrated Security=True;User Instance=True"
    Dim cn As New SqlConnection(cs)
    Dim cmd As New SqlCommand()
    Dim rd As SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Display()
        End If
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click
        Try
            cn.Open()
            cmd.Connection = cn
            cmd.CommandText = "insert into tbl_product values(" & CInt(txtproductid.Text) & ",'" & txtpname.Text & "'," & CInt(txtpprice.Text) & "," & CInt(txtqty.Text) & ", " & CInt(txtOffer.Text) & ")"
            cmd.ExecuteNonQuery()
            MsgBox("Record Saved")
        Catch ex As Exception
            MsgBox(ex.ToString())
        Finally
            cn.Close()
        End Try
        Display()
    End Sub

    Public Sub Display()
        cn.Open()
        cmd.Connection = cn
        cmd.CommandText = "Select * from tbl_product"
        rd = cmd.ExecuteReader()
        GridView1.DataSource = rd
        GridView1.DataBind()
    End Sub

    Protected Sub txtqty_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtqty.TextChanged
        txtOffer.Text = CInt(txtpprice.Text) * CInt(txtqty.Text)
    End Sub

    Protected Sub txtpprice_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtpprice.TextChanged
        txtOffer.Text = CInt(txtpprice.Text) * CInt(txtqty.Text)
    End Sub
End Class