﻿Imports System.Data.SqlClient
Public Class WebForm6
    Inherits System.Web.UI.Page

    Dim cs As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Linux\Documents\Visual Studio 2010\Projects\PriyaProject\PriyaProject\App_Data\db_bismilla.mdf;Integrated Security=True;User Instance=True"
    Dim cn As New SqlConnection(cs)
    Dim cmd As New SqlCommand()
    Dim rd As SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

    End Sub
End Class