﻿Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "priya" And txtPass.Text = "123" Then
            Response.Redirect("Home.aspx")
        Else
            MsgBox("Invalid Username or Password")
        End If

    End Sub
End Class